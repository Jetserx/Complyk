# ComplyK

Industrial compliance workspace for Kuwait contractors. Existing category forms, deadline dashboard, activity feed and CSV reports now use Supabase email/password accounts and company-scoped storage.

## Architecture

- `app/account.tsx`: sign-in, signup, password recovery, company creation and selection, sign-out.
- `lib/supabase-browser.ts`: Supabase session persistence/refresh and bearer-authenticated API requests.
- `app/api/records/route.ts`: independently validates the access token with Supabase Auth, verifies company membership, validates input, and queries using the user's token. No service-role credential is used.
- `compliance_records`: the existing app's seven record categories, scoped by `company_id`. The previously prepared domain tables are retained for future structured detail screens.
- `company_members`: owner/admin/editor may write; viewer may read. Membership cannot be self-assigned through the Data API. Team invitation management is not part of this change.
- `compliance_activity`: database-triggered, immutable client-side audit history, committed atomically with each record change.
- Existing D1 data and schema remain untouched. No D1 record migration has been performed; existing records must be assigned to a verified destination company before migration.

Supabase project: `izjedgmjiivasyigsryh` (ComplyK Production). Only the public project URL and publishable key are in source. RLS is the authorization boundary, including for callers accessing Supabase directly.

## Database changes

Applied migrations: `connect_complyk_workspace_records`, `restrict_complyk_record_column_privileges`. They add the company-scoped records and audit tables, RLS policies, indexes, audit/timestamp triggers, and column-level update privileges. The app may update record status but cannot move records between companies or edit the audit log.

## Verification

- TypeScript: `node node_modules/typescript/bin/tsc --noEmit`
- Build: use the Sites build helper.
- `tests/integration.mjs` runs the actual API handlers against Supabase, plus direct Data API access-control tests. It requires three disposable test users (`complyk-qa-1`, `complyk-qa-2`, `complyk-qa-3` at example.com) and `COMPLYK_QA_PASSWORD`. It creates synthetic companies and records. Provision fixtures only in an authorized test run and remove their records, memberships, companies, sessions and users afterward. Never use real customer credentials.

## Release checklist

Publication is pending authentication email setup and full browser validation:
1. Supabase Auth URL configuration must use the deployed ComplyK URL as Site URL and allow its exact callback URL.
2. Confirm a production email sender is configured and can deliver signup confirmation and password recovery to intended users. Default Supabase mail delivery may be restricted to organization addresses.
3. Verify confirmation, recovery, browser sign-in, company switching, record creation, reload and sign-out in the real browser.
4. Deploy the saved version after these checks pass. The existing site's audience is still private; independent customer login will require the login shell to be publicly reachable while Supabase RLS keeps records private.
